"use client";
import React from "react";

function MainComponent() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [connected, setConnected] = useState(false);

  const countries = [
    { code: "US", name: "États-Unis", flag: "🇺🇸" },
    { code: "FR", name: "France", flag: "🇫🇷" },
    { code: "GB", name: "Royaume-Uni", flag: "🇬🇧" },
    { code: "DE", name: "Allemagne", flag: "🇩🇪" },
    { code: "JP", name: "Japon", flag: "🇯🇵" },
    { code: "CA", name: "Canada", flag: "🇨🇦" },
    { code: "AU", name: "Australie", flag: "🇦🇺" },
    { code: "BR", name: "Brésil", flag: "🇧🇷" },
    { code: "IN", name: "Inde", flag: "🇮🇳" },
    { code: "CN", name: "Chine", flag: "🇨🇳" },
  ];

  const toggleConnection = () => {
    setConnected(!connected);
  };

  return (
    <div className="min-h-screen bg-[#1a1a1a] text-white p-8 font-roboto">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">VPN Mondial</h1>
          <p className="text-gray-400 text-lg">
            Connectez-vous en toute sécurité depuis n'importe où dans le monde
          </p>
        </div>

        <div className="bg-[#2a2a2a] rounded-xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <div
                className={`w-4 h-4 rounded-full ${
                  connected ? "bg-green-500" : "bg-red-500"
                }`}
              ></div>
              <span className="text-lg">
                {connected ? "Connecté" : "Déconnecté"}
              </span>
            </div>
            <button
              onClick={toggleConnection}
              className={`px-6 py-2 rounded-full font-semibold ${
                connected
                  ? "bg-red-500 hover:bg-red-600"
                  : "bg-green-500 hover:bg-green-600"
              } transition-colors`}
            >
              {connected ? "Déconnecter" : "Connecter"}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {countries.map((country) => (
              <div
                key={country.code}
                onClick={() => setSelectedCountry(country)}
                className={`p-4 rounded-lg cursor-pointer transition-all ${
                  selectedCountry?.code === country.code
                    ? "bg-[#3a3a3a] border-2 border-blue-500"
                    : "bg-[#333333] hover:bg-[#3a3a3a]"
                }`}
              >
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{country.flag}</span>
                  <div>
                    <h3 className="font-medium">{country.name}</h3>
                    <p className="text-sm text-gray-400">{country.code}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {selectedCountry && (
            <div className="mt-8 p-4 bg-[#333333] rounded-lg">
              <h3 className="text-lg font-semibold mb-2">
                Serveur sélectionné
              </h3>
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{selectedCountry.flag}</span>
                <span>{selectedCountry.name}</span>
              </div>
            </div>
          )}
        </div>

        <div className="mt-8 text-center text-gray-400">
          <p className="text-sm">
            Statut du serveur:{" "}
            {connected ? "Optimal" : "En attente de connexion"}
          </p>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;